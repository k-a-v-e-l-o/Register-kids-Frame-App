/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registerkidsapp;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

/**
 *
 * @author sepit
 */
public class RegisterAppGUI extends JFrame{
    
    //Panels
    private JPanel headingPnl;
    private JPanel namePnl;
    private JPanel genderPnl;
    private JPanel nameAndGender;
    private JPanel btnsPnl;
    private JPanel txtAreaPnl;
    private JPanel mainPnl;
    
    //labels
    private JLabel headingLbl;
    private JLabel nameLbl;
    private JLabel genderLbl;

    //txtflds
    private static JTextField nametxtFld;
    
    //txtarea
    private static JTextArea displayTxtArea;
    
    //radiobuttons
    private static JRadioButton maleRdBtn;
    private static JRadioButton femaleRdBtn;
    
    //butttons
    private JButton registerBtn;
    private JButton displayBtn;
    
    
    
    
    public RegisterAppGUI(){
     
        //configure the gui
        this.setSize(400, 400);
        this.setTitle("CRECHE 4 YOUR KIDDIE");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(true);
        this.setBackground(Color.yellow);
        
        //create the panels
       
        namePnl = new JPanel(new FlowLayout(FlowLayout.LEFT));
        genderPnl =  new JPanel(new FlowLayout(FlowLayout.LEFT));
        
        nameAndGender =  new JPanel(new GridLayout(2,1));
        
        btnsPnl = new JPanel(new FlowLayout());
        txtAreaPnl = new JPanel(new BorderLayout());
        mainPnl = new JPanel(new BorderLayout());
        
        headingPnl = new JPanel(new FlowLayout(FlowLayout.CENTER));
        headingPnl.setBorder(new BevelBorder(BevelBorder.RAISED));
        
        //create labels
        headingLbl = new JLabel("Kiddies Register");
        nameLbl = new JLabel("Name: ");
        genderLbl = new JLabel("Gender: ");
                
        //create the txtfld
        nametxtFld = new JTextField(20);
        
        //create the text area
        displayTxtArea = new JTextArea(45,45);
        displayTxtArea.setBorder(new TitledBorder(new LineBorder(Color.BLACK,2),"Display"));
        displayTxtArea.setEditable(true);
        
        //create buttons
        registerBtn = new JButton("Register kiddies");
        displayBtn = new JButton("Display kiddies");
        
        
        //create radio
        maleRdBtn = new JRadioButton("Male");
        femaleRdBtn = new JRadioButton("Female");
        
        //add the functionality on the radio buttons
        /*if(maleRdBtn.isSelected()){
        
            femaleRdBtn.setSelected(false);
        }
        else if(femaleRdBtn.isSelected()){
        
            maleRdBtn.setSelected(false);
        }*/
        
        
        //functionalities
        maleRdBtn.addActionListener(new maleRad());
        femaleRdBtn.addActionListener(new femaleRad());
        registerBtn.addActionListener(new saveData());
        displayBtn.addActionListener(new display());
        
        
        //add the namelbl and txtfld
        namePnl.add(nameLbl);
        namePnl.add(nametxtFld);
        
        //add the genderlbl and txtfld to the panel
        genderPnl.add(genderLbl);
        genderPnl.add(maleRdBtn);
        genderPnl.add(femaleRdBtn);
        
        //add the heading label to its panel
        headingPnl.add(headingLbl);
        
        //add the namepnl and genderPnl
        nameAndGender.add(namePnl);
        nameAndGender.add(genderPnl);
        
        
        //add the displaytxtArea to the pnl
        txtAreaPnl.add(displayTxtArea);
        
        //add the btns to the btnpnl
        btnsPnl.add(registerBtn);
        btnsPnl.add(displayBtn);
        
        
        
        //add the all the panels to the main pnl;
        mainPnl.add(nameAndGender,BorderLayout.NORTH);
        mainPnl.add(btnsPnl,BorderLayout.WEST);
        mainPnl.add(txtAreaPnl,BorderLayout.SOUTH);
         
        //add the mainpnl to the frame's panel 
        this.add(mainPnl,BorderLayout.CENTER);
        this.add(headingPnl,BorderLayout.NORTH);
       
        this.setVisible(true);
    }
    public static ArrayList<String> kiddiesData;
    private static class maleRad implements ActionListener {

        public maleRad() {
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
            
            
            if(maleRdBtn.isSelected()){
            
                femaleRdBtn.setSelected(false);
            }
        }
    }

    private static class femaleRad implements ActionListener {

        public femaleRad() {
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            
             if(femaleRdBtn.isSelected()){
            
                maleRdBtn.setSelected(false);
            }
        }
    }

    private static class saveData implements ActionListener {

        public saveData() {
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            
            File file = new File("myFile.txt");
            
            try{
            
                FileWriter fr = new FileWriter(file,true);
                BufferedWriter bw = new BufferedWriter(fr);
                
                String details = "";
                String name = nametxtFld.getText();
                String gender = "";
                
                
                
                if(maleRdBtn.isSelected()){
                
                    gender = "Male";
                }
                else{
                
                    gender = "Female";
                }
                bw.append(name + " " + gender);
                bw.newLine();
                bw.close();
                if(nametxtFld.equals("") && !maleRdBtn.isSelected() && !femaleRdBtn.isSelected()){
                
                    JOptionPane.showMessageDialog(null, "Fill in the missing spaces!!");

                }
                else{
                
                    JOptionPane.showMessageDialog(null, "File writing to the kiddies was successful!!");

                }
                
                
            }
            catch(IOException io){
            
               JOptionPane.showMessageDialog(null, "File writing was unsucessfull");
                
            }
        }
    }

    private static class display implements ActionListener {

        public display() {
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            
            
            File file = new File("myFile.txt");
            
            try{
            
                FileReader fr = new FileReader(file);
                BufferedReader br = new BufferedReader(fr);
                
                String text = "";
                
                while((text = br.readLine()) != null){
                
                
                    text = br.readLine();
                    displayTxtArea.setText(text);
                }
                br.close();
                
            }
            catch(IOException io){
            
                
            }
            
        }
    }
    
    
    
    
    
    
}
